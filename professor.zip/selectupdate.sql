SELECT nome_paciente,data_nascimento,current_date FROM public.tab_paciente;
ORDER BY nome_paciente ASC 
update tab_paciente set nome_paciente = 'Ana Beatriz' where id_paciente =1;