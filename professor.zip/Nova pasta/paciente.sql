create table  tab_paciente (id_paciente serial primary key,
nome_paciente varchar(60) not null, data_nascimento date not null,
cpf varchar (11),
sexo varchar (1),
num_cns varchar (15), nome_mae varchar (60)
);
insert into tab_paciente (nome_paciente, data_nascimento, cpf, sexo, num_cns, nome_mae)
values ('Freen Sarocha', '1998-08-08', '10867625449', 'F', '190919960808196', 'Cabeça de Cogumelo');
select * from tab_paciente;