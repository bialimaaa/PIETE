/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Administrador
 */
import java.util.Scanner;

public class BlackPink {
    public static void main (String[] args){
        Scanner input = new Scanner (System.in);
        String nome;
        int idade;
        
        System.out.println("Digite seu nome: ");
        nome = input.next();
        
        System.out.println("Digite sua idade: ");
        idade = input.nextInt();
        
        System.out.println("Seu nome é " + nome + " e sua idade é " + idade);
        
        input.close();
    }
    
}
