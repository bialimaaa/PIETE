create table aluno (id_aluno serial primary key,
nome_aluno varchar(70) not null,
data_nascimento date not null,
data_cadastro timestamp default current_timestamp

);
