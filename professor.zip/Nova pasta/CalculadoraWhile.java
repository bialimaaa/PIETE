import java.util.Scanner;

public class CalculadoraWhile {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Variáveis para armazenar os números e a operação
        double numero1, numero2;
        char operacao;
        boolean op = true;

        // Loop principal que continua enquanto op for true
        while (op) {
            // Solicita e lê o primeiro número
            System.out.print("Digite o primeiro número: ");
            numero1 = sc.nextDouble();  // Usando nextDouble() para aceitar números decimais

            // Solicita e lê o segundo número
            System.out.print("Digite o segundo número: ");
            numero2 = sc.nextDouble();  // Usando nextDouble() para aceitar números decimais

            // Solicita e lê a operação matemática
            System.out.print("Digite a operação (+, -, *, /): ");
            operacao = sc.next().charAt(0);

            // Calcula o resultado com base na operação escolhida
            double resultado = 0;
            if (operacao == '+') {
                resultado = numero1 + numero2;
            } else if (operacao == '-') {
                resultado = numero1 - numero2;
            } else if (operacao == '*') {
                resultado = numero1 * numero2;
            } else if (operacao == '/') {
                // Verifica divisão por zero
                if (numero2 != 0) {
                    resultado = numero1 / numero2;
                } else {
                    System.out.println("Erro: Divisão por zero!");
                    continue;  // Volta ao início do loop em caso de erro
                }
            } else {
                System.out.println("Operação inválida!");
                continue;  // Volta ao início do loop em caso de operação inválida
            }

            // Exibe o resultado da operação
            System.out.println("Resultado: " + resultado);

            // Pergunta se o usuário deseja continuar
            System.out.print("Deseja continuar? (s/n): ");
            char resposta = sc.next().charAt(0);

            // Verifica a resposta do usuário e define se o loop continua
            if (resposta == 'n' || resposta == 'N') {
                op = false;
            }
        }
        
        // Fecha o Scanner para evitar vazamento de recursos
        sc.close();
        System.out.println("Calculadora encerrada.");
    }
}