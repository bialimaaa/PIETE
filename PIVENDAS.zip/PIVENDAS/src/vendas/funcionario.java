package vendas;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 * 
 *
 * @author Administrador
 */
public class funcionario {
    private String nome;
    private String senha;
    private String endereco;
    private String sexo;
    private String telefone;
    private String cpf;
    private int id;

    public funcionario(String nome, String senha, String endereco, String sexo, String telefone, String cpf, int id) {
        this.nome = nome;
        this.senha = senha;
        this.endereco = endereco;
        this.sexo = sexo;
        this.telefone = telefone;
        this.cpf = cpf;
        this.id = id;
    }

    public funcionario(){
        
    }
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    
    
}
