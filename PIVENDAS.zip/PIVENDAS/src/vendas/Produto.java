/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vendas;

/**
 *
 * @author Administrador
 */
public class Produto {
     private String valor;
    private String senha;
    private String nome;
    private String quantidade;
    private String codbarras;
    private int id;

    public Produto(String valor, String senha, String nome, String quantidade, String codbarras, int id) {
        this.valor = valor;
        this.senha = senha;
        this.nome = nome;
        this.quantidade = quantidade;
        this.codbarras = codbarras;
        this.id = id;
    }
    public Produto(){
        
    }

    public String getValor() {
        return valor;
    }

    public String getSenha() {
        return senha;
    }

    public String getNome() {
        return nome;
    }

    public String getQuantidade() {
        return quantidade;
    }

    public String getCodbarras() {
        return codbarras;
    }

    public int getId() {
        return id;
    }

    public void setValor(String valor) {
        this.valor = valor;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setQuantidade(String quantidade) {
        this.quantidade = quantidade;
    }

    public void setCodbarras(String codbarras) {
        this.codbarras = codbarras;
    }

    public void setId(int id) {
        this.id = id;
    }
    
}
