/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vendas;

/**
 *
 * @author Administrador
 */
public class cliente {
    private String nome;
    private String senha;
    private String endereco;
    private String sexo;
    private String telefone;
    private String cpf;
    private String cnpj;
    private int id;

    public cliente(String nome, String senha, String endereco, String sexo, String nascimento, String telefone, String cpf, String cnpj, int id) {
        this.nome = nome;
        this.senha = senha;
        this.endereco = endereco;
        this.sexo = sexo;
        this.telefone = telefone;
        this.cpf = cpf;
        this.cnpj = cnpj;
        this.id = id;
    }
    public cliente(){
        
    }

    public String getNome() {
        return nome;
    }

    public String getSenha() {
        return senha;
    }

    public String getEndereco() {
        return endereco;
    }

    public String getSexo() {
        return sexo;
    }

    public String getTelefone() {
        return telefone;
    }

    public String getCpf() {
        return cpf;
    }

    public String getCnpj() {
        return cnpj;
    }

    public int getId() {
        return id;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public void setEndereco(String endere�o) {
        this.endereco = endere�o;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;

    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public void setId(int id) {
        this.id = id;
    }
    
}
