/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package util;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Classe utilit�ria para formata��o de datas e valores monet�rios.
 * Fornece m�todos para converter e formatar objetos LocalDateTime e valores double.
 */
public class Utils {
    /**
     * Formata uma data e hora no formato brasileiro (dd-MM-yyyy).
     * @param dataHora Objeto LocalDateTime contendo a data e hora a serem formatados.
     * @return String com a data formatada no padr�o "dd-MM-yyyy".
     */
    public String formatarDataHora(LocalDateTime dataHora) {
        // Cria um formatador para o padr�o brasileiro de data
        DateTimeFormatter formatoBrasileiro = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        // Formata a data e hora fornecida e retorna como string
        return dataHora.format(formatoBrasileiro);
    }
    
    /**
     * Formata uma data e hora no formato compat�vel com SQL (yyyy-MM-dd).
     * @param dataHora Objeto LocalDateTime contendo a data e hora a serem formatados.
     * @return String com a data formatada no padr�o "yyyy-MM-dd".
     */
    public String formatarDataHoraSQL(LocalDateTime dataHora) {
        // Cria um formatador para o padr�o SQL de data
        DateTimeFormatter formatoBrasileiro = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        // Formata a data e hora fornecida e retorna como string
        return dataHora.format(formatoBrasileiro);
    }
    
    /**
     * Converte uma string de data no formato "dd-MM-yyyy" para um objeto LocalDateTime.
     * @param s String contendo a data no formato "dd-MM-yyyy".
     * @return Objeto LocalDateTime representando a data fornecida, com hora definida como meia-noite.
     */
    public LocalDateTime tolocaldate(String s) {
        // Cria um parser para o padr�o brasileiro de data
        DateTimeFormatter parser = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        // Converte a string para LocalDate e define a hora como in�cio do dia (00:00)
        LocalDateTime dateTime = LocalDate.parse(s, parser).atStartOfDay();
        return dateTime;
    }
    
    /**
     * Formata um valor monet�rio como string com duas casas decimais.
     * @param x Valor double a ser formatado.
     * @return String com o valor formatado no padr�o "X.XX" (ex.: "123.45").
     */
    public String formatarMoeda(double x) {
        // Formata o valor double com duas casas decimais usando String.format
        return String.format("%.2f", x);
    }
}
