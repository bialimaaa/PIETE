/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package banco;

/**
 *
 * @author Administrador
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class conexaobanco {
    private static final String URL = "jdbc:postgresql://localhost:5432/bdvendas";
            private static final String USUARIO = "postgres";
            private static final String SENHA = "teste";
            
            
            public static Connection conectar () throws SQLException {
                try { //conexao com o driver do postgres pgAdmin
                    Class.forName ("org.postgresql.Driver");
                } catch (ClassNotFoundException e){
                    JOptionPane.showMessageDialog (null, "ERRO AO CARREGAR DRIVER");
                    throw new SQLException ("Driver do PostgreSQL n�o encontrado. Certifique-se de que o driver est� no classpath.", e);
                }
                return DriverManager.getConnection(URL, USUARIO, SENHA);
            }
    public static void fecharConexao (Connection conexao) {
if (conexao != null){
try {
if (!conexao.isClosed ()) {
conexao.close();
}
} catch (SQLException e) {
System.err.println("ERRO AO FECHAR A CONEXAO COM O BANCO DE DADOS: " + e.getMessage());
}


}
}
}


