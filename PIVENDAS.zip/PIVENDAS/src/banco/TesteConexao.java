/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package banco;

/**
 *
 * @author Administrador
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class TesteConexao {
public static void main (String [] args){
    try (Connection conexao = conexaobanco.conectar()){
        if (conexao != null && !conexao.isClosed()){
            System.out.println("Conexao com o banco estabelecida com sucesso!");
            String sql = "SELECT 1";
            try (PreparedStatement stmt = conexao.prepareStatement (sql);
                    ResultSet rs = stmt.executeQuery ()){
                
                    if(rs.next()){
                        System.out.println("Query executada com sucesso. Resultado: " +rs.getInt(1));
                    }
                     }
    } else{
            System.out.println ("Falha: Conex�o est� fechada ou nula.");
        }
}    catch (SQLException e){
    System.err.println("Erro ao conectar ou executar query: " +e.getMessage ());
    e.printStackTrace();
}
}
}

