/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package repositorio;

/**
 *
 * @author Controle Interno
 */
import vendas.cliente;
import banco.conexaobanco;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class RepCliente {
Connection con;
    
    public boolean inserir (cliente cliente) throws SQLException {
        
        con = (Connection) conexaobanco.conectar();
        
        String sql = "insert into funcionario (nome,"
                +"senha, endereco, sexo, telefone, cpf, cnpj"
                +" ) values"
                + "(?,md5(?),?,?,?,?,?))";
        
    try{
        con.setAutoCommit(false);
        PreparedStatement stmt = con.prepareStatement(sql);
        stmt.setString (1, cliente.getNome());
        stmt.setString(2, cliente.getSenha());
        stmt.setString(3, cliente.getEndereco());
        stmt.setString(4, cliente.getSexo() );
        stmt.setString (5, cliente.getTelefone());
        stmt.setString(6, cliente.getCpf());
        stmt.setString(7, cliente.getCnpj());
        
        stmt.execute();
        con.commit ();
        JOptionPane.showMessageDialog (null, "Erro ao inserir na Tabela!");
        conexaobanco.fecharConexao(con);

        return true;
    } catch(Exception ex ) {
        try {
            con.rollback();
            System.err.println(ex.getMessage());
                return false;
            } catch (SQLException exSql) {
                // Trata falha no rollback
                System.err.println(exSql.getMessage());
        }
    }
    return true;
    }
    public List<cliente> retornar() throws SQLException {
      
        // Estabelece conex�o com o banco de dados
        con = (Connection) conexaobanco.conectar();
        List<cliente> clientes = new ArrayList<>();
      
        // Query SQL para selecionar todos os registros de cliente
        String sql = "select * from cliente order by id desc";
      
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            // Itera pelo resultado e popula objetos Cliente
            while (rs.next()) {
                cliente cliente = new cliente();
                
                cliente.setId(rs.getInt("id"));
                cliente.setNome(rs.getString("nome"));
                cliente.setSenha(rs.getString("senha")); // Nota: getNString foi usado, substitu�do por getString
                cliente.setCpf(rs.getString("cpf"));
                cliente.setEndereco(rs.getString("endereco"));
                cliente.setSexo(rs.getString("sexo"));
                cliente.setTelefone(rs.getString("telefone"));
                cliente.setCnpj(rs.getString("cnpj"));
                cliente.add(cliente);
            }            
        } catch (SQLException ex) {
            // Retorna null em caso de erro (Nota: Considere lan�ar uma exce��o)
            return null;
        }
      
        // Fecha a conex�o com o banco
        conexaobanco.fecharConexao(con);
      
        return cliente;
    }  
    
    /**
     * Pesquisa um cliente por CPF.
     * @param valor O CPF a ser pesquisado.
     * @return Objeto cliente correspondente ao CPF, ou um cliente vazio se n�o encontrado.
     * @throws SQLException se ocorrer um erro no banco de dados.
     */
    public cliente pesquisarcliente(String valor) throws SQLException {
        
        // Estabelece conex�o com o banco de dados
        con = (Connection) conexaobanco.conectar();

        // Query SQL para selecionar cliente por CPF (Nota: Vulner�vel a inje��o SQL)
        String sql = "select * from funcionario where cpf = '" + valor + "'";
        cliente cliente = new cliente();

        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                
                cliente.setId(rs.getInt("id"));
                cliente.setNome(rs.getString("nome"));
                cliente.setSenha(rs.getString("senha")); // Nota: getNString foi usado, substitu�do por getString
                cliente.setCpf(rs.getString("cpf"));
                cliente.setEndereco(rs.getString("endereco"));
                cliente.setSexo(rs.getString("sexo"));
                cliente.setTelefone(rs.getString("telefone"));
                cliente.setCnpj(rs.getString("cnpj"));
              
            }

            conexaobanco.fecharConexao(con);
            
            return cliente;

        } catch (SQLException ex) {
            return null;
        }
    }
    
    /**
     * Recupera um cliente por ID.
     * @param valor O ID do cliente a ser recuperado.
     * @return Objeto cliente correspondente ao ID, ou um cliente vazio se n�o encontrado.
     * @throws SQLException se ocorrer um erro no banco de dados.
     */
    public cliente achar(int valor) throws SQLException {

        // Estabelece conex�o com o banco de dados
        con = (Connection) conexaobanco.conectar();

        // Query SQL para selecionar cliente por ID (Nota: Vulner�vel a inje��o SQL)
        String sql = "select * from cliente where id = '" + valor + "'";
        cliente cliente = new cliente();

        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
               
                cliente.setId(rs.getInt("id"));
                cliente.setNome(rs.getString("nome"));
                cliente.setSenha(rs.getString("senha")); // Nota: getNString foi usado, substitu�do por getString
                cliente.setCpf(rs.getString("cpf"));
                cliente.setEndereco(rs.getString("endereco"));
                cliente.setSexo(rs.getString("sexo"));
                cliente.setTelefone(rs.getString("telefone"));
                cliente.setCnpj(rs.getString("cnpj"));
            }

            conexaobanco.fecharConexao(con);
            return cliente;

        } catch (SQLException ex) {
            return null;
        }
    }
    
    /**
     * Atualiza um registro de cliente no banco de dados.
     * @param cliente Objeto funcionario com os dados atualizados.
     * @return true se a atualiza��o for bem-sucedida, false caso contr�rio.
     * @throws SQLException se ocorrer um erro no banco de dados.
     */
     
    public boolean atualizar (cliente cliente) throws SQLException {
        
        con = (Connection) conexaobanco.conectar();
        
        String sql = "update set cliente (nome,"
                +"senha, endereco, sexo, telefone, cpf, cnpj"
                +" ) values"
                + "(?,md5(?),?,?,?,?,?))";
    try {
        con.setAutoCommit(false);
        PreparedStatement stmt = con.prepareStatement (sql);
        stmt.setString (1, cliente.getNome());
        stmt.setString(2, cliente.getSenha());
        stmt.setString(3, cliente.getEndereco());
        stmt.setString(4, cliente.getSexo() );
        stmt.setString (5, cliente.getTelefone());
        stmt.setString(6, cliente.getCpf());
        stmt.setString(7, cliente.getCnpj());
        stmt.execute();
        
        con.commit();
        conexaobanco.fecharConexao(con);
        return true;
    } catch (SQLException ex){
        try {
            con.rollback ();
            System.err.println(ex);
            return false;
        } catch (SQLException ex1){
            System.err.println(ex1);
        }
    }
    return false;
}
    public boolean excluir (int id) throws SQLException {
        con = (Connection) conexaobanco.conectar();
        String sql = "Delete from cliente where id =?";
        try{
            con.setAutoCommit(false);
            PreparedStatement stmt = con.prepareStatement (sql);
            stmt.setInt (1, id);
            stmt.execute();
            con.commit();
            conexaobanco.fecharConexao(con);
            return true;
        } catch (SQLException ex){
            return false;
        }
    }
    public int login (String cpf, String senha) throws SQLException {
        con = (Connection) conexaobanco.conectar();
        int ret = 0;
        String sql = "select count (*) as total from cliente where cpf = '";
                try{
                    Statement stmt =  con.createStatement();
                    ResultSet rs = stmt.executeQuery(sql);
                    
                    while (rs.next()){
                        ret = rs.getInt("total");
                    }
     } catch (SQLException ex) {
            return ret;
        }
      
        // Fecha a conex�o com o banco
        conexaobanco.fecharConexao(con);
        return ret;
}
    /**
     * Recupera o nome de um cliente por CPF e senha.
     * @param cpf O CPF do cliente.
     * @param senha A senha do cliente.
     * @return O nome do cliente se autenticado, string vazia caso contr�rio.
     * @throws SQLException se ocorrer um erro no banco de dados.
     */
    public String logado(String cpf, String senha) throws SQLException {
      
        // Estabelece conex�o com o banco de dados
        con = (Connection) conexaobanco.conectar();
        String ret = "";
      
        // Query SQL para selecionar o nome do cliente (Nota: Vulner�vel a inje��o SQL)
        String sql = "select nome from cliente where cpf = '"+cpf+"' and senha = md5('"+senha+"')";
      
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                ret = rs.getString("nome");
            }
        } catch (SQLException ex) {
            return ret;
        }
      
        // Fecha a conex�o com o banco
        conexaobanco.fecharConexao(con);
        return ret;
    }
   
    /**
     * Pesquisa clientes por nome ou CPF.
     * @param valor O valor da pesquisa (nome ou CPF).
     * @param tipoPesquisa O tipo de pesquisa ("nome" ou "cpf").
     * @return Lista de objetos cliente correspondentes, ou null se ocorrer um erro.
     * @throws SQLException se ocorrer um erro no banco de dados.
     */
    public List<cliente> pesquisar(String valor, String tipoPesquisa) throws SQLException {

        // Estabelece conex�o com o banco de dados
        con = (Connection) conexaobanco.conectar();
        List<cliente> cliente = new ArrayList<>();

        // Constr�i a query SQL com base no tipo de pesquisa (Nota: Vulner�vel a inje��o SQL para nome)
        String sql = "";
        if (tipoPesquisa.equals("nome")) {
            sql = "select * from cliente where nome like '%" + valor + "%'";
        } else if (tipoPesquisa.equals("cpf")) {
            sql = "select * from cliente where cpf = '" + valor + "'";
        }

        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                
                cliente cliente = new cliente();

                cliente.setId(rs.getInt("id"));
                cliente.setNome(rs.getString("nome"));
                cliente.setSenha(rs.getString("senha")); // Nota: getNString foi usado, substitu�do por getString
                cliente.setCpf(rs.getString("cpf"));
                cliente.setEndereco(rs.getString("endereco"));
                cliente.setSexo(rs.getString("sexo"));
                cliente.setTelefone(rs.getString("telefone"));
                cliente.setCnpj(rs.getString("cnpj"));
                cliente.add(cliente);
            }
        } catch (SQLException ex) {
            return null;
        }

        // Fecha a conex�o com o banco
        conexaobanco.fecharConexao(con);

        return cliente;
    }
}
