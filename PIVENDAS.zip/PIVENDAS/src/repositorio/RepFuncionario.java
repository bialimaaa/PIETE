/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package repositorio;

/**
 *
 * @author Administrador
 */

import vendas.funcionario;
import banco.conexaobanco;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class RepFuncionario {
    
    Connection con;
    
    public boolean inserir (funcionario funcionario) throws SQLException {
        
        con = (Connection) conexaobanco.conectar();
        
        String sql = "insert into funcionario (nome,"
                +"senha, endereco, sexo, telefone, cpf"
                +" ) values"
                + "(?,md5(?),?,?,?,?))";
        
    try{
        con.setAutoCommit(false);
        PreparedStatement stmt = con.prepareStatement(sql);
        stmt.setString (1, funcionario.getNome());
        stmt.setString(2, funcionario.getSenha());
        stmt.setString(3, funcionario.getEndereco());
        stmt.setString(4, funcionario.getSexo() );
        stmt.setString (5, funcionario.getTelefone());
        stmt.setString(6, funcionario.getCpf());
        
        stmt.execute();
        con.commit ();
        JOptionPane.showMessageDialog (null, "Erro ao inserir na Tabela!");
        conexaobanco.fecharConexao(con);

        return true;
    } catch(Exception ex ) {
        try {
            con.rollback();
            System.err.println(ex.getMessage());
                return false;
            } catch (SQLException exSql) {
                // Trata falha no rollback
                System.err.println(exSql.getMessage());
        }
    }
    return true;
    }
    public List<funcionario> retornar() throws SQLException {
      
        // Estabelece conex�o com o banco de dados
        con = (Connection) conexaobanco.conectar();
        List<funcionario> funcionarios = new ArrayList<>();
      
        // Query SQL para selecionar todos os registros de alunos
        String sql = "select * from funcionario order by id desc";
      
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            // Itera pelo resultado e popula objetos Aluno
            while (rs.next()) {
                funcionario funcionario = new funcionario();
                
                funcionario.setId(rs.getInt("id"));
                funcionario.setNome(rs.getString("nome"));
                funcionario.setSenha(rs.getString("senha")); // Nota: getNString foi usado, substitu�do por getString
                funcionario.setCpf(rs.getString("cpf"));
                funcionario.setEndereco(rs.getString("endereco"));
                funcionario.setSexo(rs.getString("sexo"));
                funcionario.setTelefone(rs.getString("telefone"));
                funcionarios.add(funcionario);
            }            
        } catch (SQLException ex) {
            // Retorna null em caso de erro (Nota: Considere lan�ar uma exce��o)
            return null;
        }
      
        // Fecha a conex�o com o banco
        conexaobanco.fecharConexao(con);
      
        return funcionarios;
    }  
    
    /**
     * Pesquisa um funcionario por CPF.
     * @param valor O CPF a ser pesquisado.
     * @return Objeto Aluno correspondente ao CPF, ou um Aluno vazio se n�o encontrado.
     * @throws SQLException se ocorrer um erro no banco de dados.
     */
    public funcionario pesquisarfuncionario(String valor) throws SQLException {
        
        // Estabelece conex�o com o banco de dados
        con = (Connection) conexaobanco.conectar();

        // Query SQL para selecionar aluno por CPF (Nota: Vulner�vel a inje��o SQL)
        String sql = "select * from funcionario where cpf = '" + valor + "'";
        funcionario funcionario = new funcionario();

        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                
                funcionario.setId(rs.getInt("id"));
                funcionario.setNome(rs.getString("nome"));
                funcionario.setSenha(rs.getString("senha")); // Nota: getNString foi usado, substitu�do por getString
                funcionario.setCpf(rs.getString("cpf"));
                funcionario.setEndereco(rs.getString("endereco"));
                funcionario.setSexo(rs.getString("sexo"));
                funcionario.setTelefone(rs.getString("telefone"));
              
            }

            conexaobanco.fecharConexao(con);
            return funcionario;

        } catch (SQLException ex) {
            return null;
        }
    }
    
    /**
     * Recupera um funcionario por ID.
     * @param valor O ID do aluno a ser recuperado.
     * @return Objeto funcionario correspondente ao ID, ou um funcionario vazio se n�o encontrado.
     * @throws SQLException se ocorrer um erro no banco de dados.
     */
    public funcionario achar(int valor) throws SQLException {

        // Estabelece conex�o com o banco de dados
        con = (Connection) conexaobanco.conectar();

        // Query SQL para selecionar aluno por ID (Nota: Vulner�vel a inje��o SQL)
        String sql = "select * from funcionario where id = '" + valor + "'";
        funcionario funcionario = new funcionario();

        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
               
                funcionario.setId(rs.getInt("id"));
                funcionario.setNome(rs.getString("nome"));
                funcionario.setSenha(rs.getString("senha")); // Nota: getNString foi usado, substitu�do por getString
                funcionario.setCpf(rs.getString("cpf"));
                funcionario.setEndereco(rs.getString("endereco"));
                funcionario.setSexo(rs.getString("sexo"));
                funcionario.setTelefone(rs.getString("telefone"));
            }

            conexaobanco.fecharConexao(con);
            return funcionario;

        } catch (SQLException ex) {
            return null;
        }
    }
    
    /**
     * Atualiza um registro de funcionario no banco de dados.
     * @param funcionario Objeto funcionario com os dados atualizados.
     * @return true se a atualiza��o for bem-sucedida, false caso contr�rio.
     * @throws SQLException se ocorrer um erro no banco de dados.
     */
     
    public boolean atualizar (funcionario funcionario) throws SQLException {
        
        con = (Connection) conexaobanco.conectar();
        
        String sql = "update funcionario set senha (nome,"
                +"senha, endereco, sexo, telefone, cpf"
                +" ) values"
                + "(?,md5(?),?,?,?,?))";
    try {
        con.setAutoCommit(false);
        PreparedStatement stmt = con.prepareStatement (sql);
        stmt.setString (1, funcionario.getNome());
        stmt.setString(2, funcionario.getSenha());
        stmt.setString(3, funcionario.getEndereco());
        stmt.setString(4, funcionario.getSexo() );
        stmt.setString (5, funcionario.getTelefone());
        stmt.setString(6, funcionario.getCpf());
        stmt.execute();
        
        con.commit();
        conexaobanco.fecharConexao(con);
        return true;
    } catch (SQLException ex){
        try {
            con.rollback ();
            System.err.println(ex);
            return false;
        } catch (SQLException ex1){
            System.err.println(ex1);
        }
    }
    return false;
}
    public boolean excluir (int id) throws SQLException {
        con = (Connection) conexaobanco.conectar();
        String sql = "Delete from funcionario where id =?";
        try{
            con.setAutoCommit(false);
            PreparedStatement stmt = con.prepareStatement (sql);
            stmt.setInt (1, id);
            stmt.execute();
            con.commit();
            conexaobanco.fecharConexao(con);
            return true;
        } catch (SQLException ex){
            return false;
        }
    }
    public int login (String cpf, String senha) throws SQLException {
        con = (Connection) conexaobanco.conectar();
        int ret = 0;
        String sql = "select count (*) as total from funcionario where cpf = '";
                try{
                    Statement stmt =  con.createStatement();
                    ResultSet rs = stmt.executeQuery(sql);
                    
                    while (rs.next()){
                        ret = rs.getInt("total");
                    }
     } catch (SQLException ex) {
            return ret;
        }
      
        // Fecha a conex�o com o banco
        conexaobanco.fecharConexao(con);
        return ret;
}
    /**
     * Recupera o nome de um aluno por CPF e senha.
     * @param cpf O CPF do aluno.
     * @param senha A senha do aluno.
     * @return O nome do aluno se autenticado, string vazia caso contr�rio.
     * @throws SQLException se ocorrer um erro no banco de dados.
     */
    public String logado(String cpf, String senha) throws SQLException {
      
        // Estabelece conex�o com o banco de dados
        con = (Connection) conexaobanco.conectar();
        String ret = "";
      
        // Query SQL para selecionar o nome do aluno (Nota: Vulner�vel a inje��o SQL)
        String sql = "select nome from funcionario where cpf = '"+cpf+"' and senha = md5('"+senha+"')";
      
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                ret = rs.getString("nome");
            }
        } catch (SQLException ex) {
            return ret;
        }
      
        // Fecha a conex�o com o banco
        conexaobanco.fecharConexao(con);
        return ret;
    }
   
    /**
     * Pesquisa funcionarios por nome ou CPF.
     * @param valor O valor da pesquisa (nome ou CPF).
     * @param tipoPesquisa O tipo de pesquisa ("nome" ou "cpf").
     * @return Lista de objetos funcionario correspondentes, ou null se ocorrer um erro.
     * @throws SQLException se ocorrer um erro no banco de dados.
     */
    public List<funcionario> pesquisar(String valor, String tipoPesquisa) throws SQLException {

        // Estabelece conex�o com o banco de dados
        con = (Connection) conexaobanco.conectar();
        List<funcionario> funcionarios = new ArrayList<>();

        // Constr�i a query SQL com base no tipo de pesquisa (Nota: Vulner�vel a inje��o SQL para nome)
        String sql = "";
        if (tipoPesquisa.equals("nome")) {
            sql = "select * from funcionario where nome like '%" + valor + "%'";
        } else if (tipoPesquisa.equals("cpf")) {
            sql = "select * from funcionario where cpf = '" + valor + "'";
        }

        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                funcionario funcionario = new funcionario();

                funcionario.setId(rs.getInt("id"));
                funcionario.setNome(rs.getString("nome"));
                funcionario.setSenha(rs.getString("senha")); // Nota: getNString foi usado, substitu�do por getString
                funcionario.setCpf(rs.getString("cpf"));
                funcionario.setEndereco(rs.getString("endereco"));
                funcionario.setSexo(rs.getString("sexo"));
                funcionario.setTelefone(rs.getString("telefone"));
                funcionarios.add(funcionario);
            }
        } catch (SQLException ex) {
            return null;
        }

        // Fecha a conex�o com o banco
        conexaobanco.fecharConexao(con);

        return funcionarios;
    }
}