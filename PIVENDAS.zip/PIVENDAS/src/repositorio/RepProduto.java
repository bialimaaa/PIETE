/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package repositorio;

/**
 *
 * @author Controle Interno
 */
import banco.conexaobanco;
import vendas.Produto;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
//Classe de reposit�rio para gerenciar dados de produto no banco de dados.
public class RepProduto {
    // Objeto de conex�o com o banco de dados
    Connection con;
    
    /**
     * Insere um novo registro de produto no banco de dados.
     * @param produto Objeto produto contendo os dados do produto.
     * @return true se a inser��o for bem-sucedida, false caso contr�rio.
     * @throws SQLException se ocorrer um erro no banco de dados.
     */
    public boolean inserir(Produto produto) throws SQLException {
        
        // Estabelece conex�o com o banco de dados
        con = (Connection) conexaobanco.conectar(); 
        
        // Query SQL para inserir dados do produto
        String sql = "insert into produtos (valor,"
                +"senha, nome, quantidade, codbarras"
                +" ) values"
                + "(?,md5(?),?,?,?))";
        
        try {
            // Desativa auto-commit para gerenciar transa��es manualmente
            con.setAutoCommit(false);
            PreparedStatement stmt = con.prepareStatement(sql);
            
            // Define os valores dos par�metros para a query
            stmt.setString(1, produto.getValor());
            stmt.setString(2, produto.getSenha());
            stmt.setString(3, produto.getNome());
            stmt.setString(4, produto.getQuantidade());
            stmt.setString(5, produto.getCodbarras());
            
            // Executa a query de inser��o
            stmt.execute();
            // Confirma a transa��o
            con.commit();
            // Fecha a conex�o com o banco
            conexaobanco.fecharConexao(con);
            
            return true;
        } catch (Exception ex) {
            try {
                // Reverte a transa��o em caso de erro
                con.rollback();
                System.err.println(ex.getMessage());
                return false;
            } catch (SQLException exSql) {
                // Trata falha no rollback
                System.err.println(exSql.getMessage());
            }
        }
        
        // Retorna true como fallback (Nota: Pode ser enganoso se ocorrer uma exce��o)
        return true;
    }
    
    /**
     * Retorna todos os registros de Produto do banco de dados, ordenados por ID em ordem decrescente.
     * @return Lista de objetos produto, ou null se ocorrer um erro.
     * @throws SQLException se ocorrer um erro no banco de dados.
     */
    public List<Produto> retornar() throws SQLException {
      
        // Estabelece conex�o com o banco de dados
        con = (Connection) conexaobanco.conectar();
        List<Produto> produto = new ArrayList<>();
      
        // Query SQL para selecionar todos os registros de produto
        String sql = "select * from produto order by id desc";
      
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            // Itera pelo resultado e popula objetos produto
            while (rs.next()) {
                
                Produto produto = new Produto();
                
                produto.setId(rs.getInt("id"));
                produto.setValor(rs.getString("valor"));
                produto.setSenha(rs.getString("senha")); // Nota: getNString foi usado, substitu�do por getString
                produto.setNome(rs.getString("nome"));
                produto.setQuantidade(rs.getString("quantidade"));
                produto.setCodbarras(rs.getString("codbarras"));
                produto.add(produto);
            }            
        } catch (SQLException ex) {
            // Retorna null em caso de erro (Nota: Considere lan�ar uma exce��o)
            return null;
        }
      
        // Fecha a conex�o com o banco
        conexaobanco.fecharConexao(con);
      
        return produto;
    }  
    
    /**
     * Retorna todos os produtos dispon�veis (disponibilidade = 'Sim') do banco de dados.
     * @return Lista de objetos produto dispon�veis, ou null se ocorrer um erro.
     * @throws SQLException se ocorrer um erro no banco de dados.
     */
    public List<Produto> disponiveis() throws SQLException {
      
        // Estabelece conex�o com o banco de dados
        con = (Connection) conexaobanco.conectar();
        List<Produto> produto = new ArrayList<>();
      
        // Query SQL para selecionar produtos dispon�veis
        String sql = "select * from produtos where disponibilidade = 'Sim'";
      
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            // Itera pelo resultado e popula objetos produtos
            while (rs.next()) {
            Produto produto = new Produto();
                
                produto.setId(rs.getInt("id"));
                produto.setValor(rs.getString("valor"));
                produto.setSenha(rs.getString("senha")); // Nota: getNString foi usado, substitu�do por getString
                produto.setNome(rs.getString("nome"));
                produto.setQuantidade(rs.getString("quantidade"));
                produto.setCodbarras(rs.getString("codbarras"));
                produto.add(produto);
            }            
        } catch (SQLException ex) {
            // Retorna null em caso de erro (Nota: Considere lan�ar uma exce��o)
            return null;
        }
      
        // Fecha a conex�o com o banco
        conexaobanco.fecharConexao(con);
      
        return produto;
    }
    
    /**
     * Atualiza um registro de produto no banco de dados.
     * @param produto Objeto produto com os dados atualizados.
     * @return true se a atualiza��o for bem-sucedida, false caso contr�rio.
     * @throws SQLException se ocorrer um erro no banco de dados.
     */
    public boolean atualizar(Produto produto) throws SQLException {

        // Estabelece conex�o com o banco de dados
        con = (Connection) conexaobanco.conectar();
        // Query SQL para atualizar dados do produto
        
         String sql = "update produtos set quantidade (valor,"
                +"senha, nome, quantidade, codbarras"
                +" ) values"
                + "(?,md5(?),?,?,?))";
        try {
            // Desativa auto-commit para gerenciar transa��es manualmente
            con.setAutoCommit(false);
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setString(1, produto.getValor());
            stmt.setString(2, produto.getSenha());
            stmt.setString(3, produto.getNome());
            stmt.setString(4, produto.getQuantidade());
            stmt.setString(5, produto.getCodbarras()); 
            
            // Executa a query de atualiza��o
            stmt.execute();
            // Confirma a transa��o
            con.commit();
            // Fecha a conex�o com o banco
           conexaobanco.fecharConexao(con);

            return true;
        } catch (SQLException ex) {
            try {
                // Reverte a transa��o em caso de erro
                con.rollback();
                System.err.println(ex);
                return false;
            } catch (SQLException ex1) {
                // Trata falha no rollback
                System.err.println(ex1);
            }

            return false;
        }
}
    public Produto achar(int valor) throws SQLException {

        // Estabelece conex�o com o banco de dados
        con = (Connection) conexaobanco.conectar();

        // Query SQL para selecionar produto por ID (Nota: Vulner�vel a inje��o SQL)
        String sql = "select * from produtos where id = '" + valor + "'";
        Produto produto = new Produto();

        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
               
                
                produto.setId(rs.getInt("id"));
                produto.setValor(rs.getString("valor"));
                produto.setSenha(rs.getString("senha")); // Nota: getNString foi usado, substitu�do por getString
                produto.setNome(rs.getString("nome"));
                produto.setQuantidade(rs.getString("quantidade"));
                produto.setCodbarras(rs.getString("codbarras"));
            }

            conexaobanco.fecharConexao(con);
            return produto;

        } catch (SQLException ex) {
            return null;
        }
    }
     public boolean excluir (int id) throws SQLException {
        con = (Connection) conexaobanco.conectar();
        String sql = "Delete from produto where id =?";
        try{
            con.setAutoCommit(false);
            PreparedStatement stmt = con.prepareStatement (sql);
            stmt.setInt (1, id);
            stmt.execute();
            con.commit();
            conexaobanco.fecharConexao(con);
            return true;
        } catch (SQLException ex){
            return false;
        }
}
}